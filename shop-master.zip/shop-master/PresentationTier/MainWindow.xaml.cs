﻿using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DataTier;
using LogicTier;
using Microsoft.Win32;

namespace PresentationTier;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    private Автосалон автосалон;
    private ObservableCollection<string> items = new ObservableCollection<string>();
    public MainWindow()
    {
        автосалон = new Автосалон(); // пока пустой
        this.DataContext = автосалон;
        InitializeComponent();
    }
    private void ImportButton_Click(object sender, RoutedEventArgs e)
    {
        var автоИзФайла = Автомобили.ПолучитьВсеАвтомобилиИзФайла();

        if (автоИзФайла == null || автоИзФайла.Count == 0)
        {
            MessageBox.Show("Файл пуст или повреждён!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        автосалон.ЗагрузитьАвтомобили(автоИзФайла);
    }


    private void BtnAdd_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var товар = new DataTier.Автомобиль
            {
                Модель = TxtCode.Text,
                Производитель = myComboBox.Text,
                Стоимость = float.Parse(TxtPrice.Text),
                Пробег = int.Parse(TxtQuantity.Text)
            };

            var позиция = new LogicTier.АвтомобильнаяПозиция(товар); // оборачиваем

            var магазин = (LogicTier.Автосалон)DataContext;
            магазин.СписокАвтомобилей.Add(позиция); // добавляем в список

            TxtCode.Clear();
            myComboBox.SelectedIndex=-1;
            TxtPrice.Clear();
            TxtQuantity.Clear();

        }
        catch (Exception ex)
        {
            MessageBox.Show("Ошибка при добавлении товара: " + ex.Message, "Ошибка");
        }
    }

    private void BtnCreateFile_Click(object sender, RoutedEventArgs e)
    {
        SaveFileDialog sfd = new SaveFileDialog();
        sfd.Filter = "Текстовые файлы(*.txt)|*.txt|Скрипты(*.sql)|*.sql|Документы(*.docx)|*.docx";

        if (sfd.ShowDialog() == true)
        {
            string FilePath = sfd.FileName;
            using (StreamWriter swriter = new StreamWriter(FilePath))
            {
                var магазин = (LogicTier.Автосалон)DataContext;

                int номер = 1;
                foreach (var товар in магазин.СписокАвтомобилей)
                {
                    //форматируем строку в нужный вид
                    string строка = $" {товар.Модель} ; {товар.Производитель} ; {товар.Стоимость:0.00} ; {товар.Пробег:0.00}";
                    swriter.WriteLine(строка);
                    номер++;
                }
            }

            MessageBox.Show($"Данные сохранены в файл {FilePath}");
        }
        else
        {
            MessageBox.Show("Пользователь отказался от окна сохранения");
        }
    }

    private void BtnDelete_Click(object sender, RoutedEventArgs e)
    {
        if (MainList.SelectedItems.Count == 0)
        {
            MessageBox.Show("Пожалуйста, выделите элементы для удаления.", "Предупреждение");
            return;
        }
        //получаем объект Магазин из DataContext 
        var магазин = (LogicTier.Автосалон)DataContext;
        //преобразуем выбранные элементы в список ТоварнаяПозиация
        var itemsToRemove = MainList.SelectedItems.Cast<LogicTier.АвтомобильнаяПозиция>().ToList(); //приводим элементы к типу ТоварнаяПозиация

        foreach (var item in itemsToRemove)
        {
            магазин.СписокАвтомобилей.Remove(item); //удаляем из коллекции ObservableCollection
        }
    }
    private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (myComboBox.SelectedItem != null)
        {
            var selectedItem = (System.Windows.Controls.ComboBoxItem)myComboBox.SelectedItem;
            MessageBox.Show($"Выбрано: {selectedItem.Content}");
        }
    }
}