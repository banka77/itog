﻿using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DataTier;
using LogicTier;
using Microsoft.Win32;

namespace PresentationTier;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    private Автосалон автосалон;
    private ObservableCollection<string> items = new ObservableCollection<string>();
    public MainWindow()
    {
        автосалон = new Автосалон(); // пока пустой
        this.DataContext = автосалон;
        InitializeComponent();
    }
    private void ImportButton_Click(object sender, RoutedEventArgs e)
    {
        var автоИзФайла = Автомобили.ПолучитьВсеАвтомобилиИзФайла();

        if (автоИзФайла == null || автоИзФайла.Count == 0)
        {
            MessageBox.Show("Файл пуст или повреждён!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        автосалон.ЗагрузитьАвтомобили(автоИзФайла);

        try
        {
            // Путь на рабочий стол
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            string tableFilePath = System.IO.Path.Combine(desktopPath, "ТаблицаАвто.txt");


            using (StreamWriter writer = new StreamWriter(tableFilePath, false, Encoding.UTF8))
            {
                writer.WriteLine("| Модель           | Производитель      | Стоимость     | Пробег   |");
                writer.WriteLine("|------------------|---------------------|---------------|----------|");

                foreach (var авто in автоИзФайла)
                {
                    writer.WriteLine($"| {авто.Модель,-16} | {авто.Производитель,-19} | {авто.Стоимость,11:0.00} ₽ | {авто.Пробег,7} км |");
                }
            }

            MessageBox.Show($"Таблица успешно создана на рабочем столе!\n{tableFilePath}", "Успех");
        }
        catch (Exception ex)
        {
            MessageBox.Show("Ошибка при создании таблицы: " + ex.Message, "Ошибка");
        }
    }


    private void BtnAdd_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var товар = new DataTier.Автомобиль
            {
                Модель = TxtCode.Text,
                Производитель = myComboBox.Text,
                Стоимость = float.Parse(TxtPrice.Text),
                Пробег = int.Parse(TxtQuantity.Text)
            };

            var позиция = new LogicTier.АвтомобильнаяПозиция(товар); // оборачиваем

            var магазин = (LogicTier.Автосалон)DataContext;
            магазин.СписокАвтомобилей.Add(позиция); // добавляем в список

            TxtCode.Clear();
            myComboBox.SelectedIndex=-1;
            TxtPrice.Clear();
            TxtQuantity.Clear();

        }
        catch (Exception ex)
        {
            MessageBox.Show("Ошибка при добавлении товара: " + ex.Message, "Ошибка");
        }
    }

    private void BtnCreateFile_Click(object sender, RoutedEventArgs e)
    {
        SaveFileDialog sfd = new SaveFileDialog
        {
            Filter = "JSON файлы (*.json)|*.json|Все файлы (*.*)|*.*"
        };

        if (sfd.ShowDialog() == true)
        {
            string filePath = sfd.FileName;
            var магазин = (LogicTier.Автосалон)DataContext;

            // Преобразуем все позиции в обычные Автомобили
            var списокАвтомобилей = магазин.СписокАвтомобилей.Select(п => new DataTier.Автомобиль
            {
                Модель = п.Модель,
                Производитель = п.Производитель,
                Стоимость = п.Стоимость,
                Пробег = п.Пробег
            }).ToList();

            var options = new JsonSerializerOptions
            {
                WriteIndented = true,
                Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
            };

            string jsonContent = JsonSerializer.Serialize(списокАвтомобилей, options);

            File.WriteAllText(filePath, jsonContent, Encoding.UTF8);


            File.WriteAllText(filePath, jsonContent, Encoding.UTF8);

            MessageBox.Show($"Файл сохранён как JSON:\n{filePath}", "Успех");
        }
        else
        {
            MessageBox.Show("Пользователь отменил сохранение");
        }
    }



    private void BtnDelete_Click(object sender, RoutedEventArgs e)
    {
        if (MainList.SelectedItems.Count == 0)
        {
            MessageBox.Show("Пожалуйста, выделите элементы для удаления.", "Предупреждение");
            return;
        }
        //получаем объект Магазин из DataContext 
        var магазин = (LogicTier.Автосалон)DataContext;
        //преобразуем выбранные элементы в список ТоварнаяПозиация
        var itemsToRemove = MainList.SelectedItems.Cast<LogicTier.АвтомобильнаяПозиция>().ToList(); //приводим элементы к типу ТоварнаяПозиация

        foreach (var item in itemsToRemove)
        {
            магазин.СписокАвтомобилей.Remove(item); //удаляем из коллекции ObservableCollection
        }
    }
    private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (myComboBox.SelectedItem != null)
        {
            var selectedItem = (System.Windows.Controls.ComboBoxItem)myComboBox.SelectedItem;
            MessageBox.Show($"Выбрано: {selectedItem.Content}");
        }
    }

    private void BtnFind_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            // Сначала выбираем файл
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "JSON Files (*.json)|*.json"
            };

            if (openFileDialog.ShowDialog() != true)
            {
                return;
            }

            string json = File.ReadAllText(openFileDialog.FileName, Encoding.UTF8);

            // Теперь спрашиваем ключ для поиска
            string ключ = Microsoft.VisualBasic.Interaction.InputBox(
                "Введите ключ для поиска в JSON:",
                "Поиск значения",
                ""
            );

            if (string.IsNullOrWhiteSpace(ключ))
            {
                MessageBox.Show("Ключ не введён.", "Ошибка");
                return;
            }

            // Список для хранения найденных значений
            List<string> найденныеЗначения = new List<string>();

            using var document = JsonDocument.Parse(json);
            JsonElement root = document.RootElement;

            if (root.ValueKind == JsonValueKind.Array)
            {
                // Если корень — массив, ищем в каждом объекте массива
                foreach (var элемент in root.EnumerateArray())
                {
                    if (элемент.ValueKind == JsonValueKind.Object && элемент.TryGetProperty(ключ, out JsonElement значение))
                    {
                        найденныеЗначения.Add(значение.ToString());
                    }
                }

                if (найденныеЗначения.Count == 0)
                {
                    MessageBox.Show($"Ключ '{ключ}' не найден в массиве.", "Информация");
                }
                else
                {
                    // Если что-то нашли — показываем
                    string всеЗначения = string.Join("\n", найденныеЗначения);
                    MessageBox.Show($"Найденные значения для ключа '{ключ}':\n{всеЗначения}", "Результат поиска");
                }
            }
            else
            {
                MessageBox.Show("Ожидался JSON-массив в корне.", "Ошибка");
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Ошибка поиска: " + ex.Message, "Ошибка");
        }

    }
}
