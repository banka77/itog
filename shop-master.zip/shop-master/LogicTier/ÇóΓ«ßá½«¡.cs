﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using DataTier;

namespace LogicTier
{
    public class Автосалон : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private ObservableCollection<АвтомобильнаяПозиция> _автомобили;

        public Автосалон()
        {
            _автомобили = new ObservableCollection<АвтомобильнаяПозиция>();
            _автомобили.CollectionChanged += (s, e) => ОбновитьСвойства();
        }

        public Автосалон(List<АвтомобильнаяПозиция> позиции)
        {
            _автомобили = new ObservableCollection<АвтомобильнаяПозиция>(позиции);
            _автомобили.CollectionChanged += (s, e) => ОбновитьСвойства();
        }

        public ObservableCollection<АвтомобильнаяПозиция> СписокАвтомобилей => _автомобили;

        public string НаименованиеАвтосалона => "Наш автосалон";

        public float СуммарнаяСтоимость => _автомобили.Sum(авто => авто.Стоимость);

        public АвтомобильнаяПозиция АвтоСНаименьшимПробегом =>
            _автомобили.OrderBy(авто => авто.Пробег).FirstOrDefault();

        private void ОбновитьСвойства()
        {
            OnPropertyChanged(nameof(СуммарнаяСтоимость));
            OnPropertyChanged(nameof(АвтоСНаименьшимПробегом));
        }

        protected void OnPropertyChanged(string имя)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(имя));
        }

        public void ЗагрузитьАвтомобили(List<Автомобиль> список)
        {
            _автомобили.Clear();
            foreach (var авто in список)
            {
                _автомобили.Add(new АвтомобильнаяПозиция(авто));
            }
            ОбновитьСвойства();
        }
    }
}
