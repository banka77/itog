﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Json;

namespace DataTier
{
    public class Автомобили
    {
        public static List<Автомобиль> ПолучитьВсеАвтомобилиИзФайла()
        {
            List<Автомобиль> list = new List<Автомобиль>();

            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "JSON файлы (*.json)|*.json|Все файлы (*.*)|*.*"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                string filePath = openFileDialog.FileName;
                string jsonContent = File.ReadAllText(filePath, Encoding.UTF8);

                list = JsonSerializer.Deserialize<List<Автомобиль>>(jsonContent);
            }

            return list ?? new List<Автомобиль>();
        }
    }
}
